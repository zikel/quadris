//
//  divider.h
//  quadris
//
//  Created by Lu Cheng on 2018-07-16.
//  Copyright © 2018 Lu Cheng. All rights reserved.
//

#ifndef _DIVIDER_HEADER_
#define _DIVIDER_HEADER_

#include "block.h"

class Divider: public Block {
    
public:
    Divider();
};

#endif
