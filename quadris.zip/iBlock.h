//
//  iBlock.h
//  quadris
//
//  Created by Lu Cheng on 2018-07-16.
//  Copyright © 2018 Lu Cheng. All rights reserved.
//

#ifndef _IBLOCK_HEADER_
#define _IBLOCK_HEADER_

#include "block.h"

class IBlock: public Block {
    
public:
    IBlock(bool heavy);
};

#endif
