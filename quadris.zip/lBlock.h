//
//  lBlock.h
//  quadris
//
//  Created by Lu Cheng on 2018-07-16.
//  Copyright © 2018 Lu Cheng. All rights reserved.
//

#ifndef _LBLOCK_HEADER_
#define _LBLOCK_HEADER_

#include "block.h"

class LBlock: public Block {
    
public:
    LBlock(bool heavy);
};

#endif
