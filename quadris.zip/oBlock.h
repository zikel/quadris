//
//  oBlock.h
//  quadris
//
//  Created by Lu Cheng on 2018-07-16.
//  Copyright © 2018 Lu Cheng. All rights reserved.
//

#ifndef _OBLOCK_HEADER_
#define _OBLOCK_HEADER_

#include "block.h"

class OBlock: public Block {
    
public:
    OBlock(bool heavy);
};

#endif
