//
//  sBlock.h
//  quadris
//
//  Created by Lu Cheng on 2018-07-16.
//  Copyright © 2018 Lu Cheng. All rights reserved.
//

#ifndef _SBLOCK_HEADER_
#define _SBLOCK_HEADER_

#include "block.h"

class SBlock: public Block {
    
public:
    SBlock(bool heavy);
};

#endif
