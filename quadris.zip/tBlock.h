//
//  tBlock.h
//  quadris
//
//  Created by Lu Cheng on 2018-07-16.
//  Copyright © 2018 Lu Cheng. All rights reserved.
//

#ifndef _TBLOCK_HEADER_
#define _TBLOCK_HEADER_

#include "block.h"

class TBlock: public Block {
    
public:
    TBlock(bool heavy);
};

#endif
