//
//  zBlock.h
//  quadris
//
//  Created by Lu Cheng on 2018-07-16.
//  Copyright © 2018 Lu Cheng. All rights reserved.
//

#ifndef _ZBLOCK_HEADER_
#define _ZBLOCK_HEADER_

#include "block.h"

class ZBlock: public Block {
    
public:
    ZBlock(bool heavy);
};

#endif

